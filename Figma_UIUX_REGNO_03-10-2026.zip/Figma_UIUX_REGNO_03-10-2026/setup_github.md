# Push to GitHub – Step by Step

1. Rename this folder, replacing REGNO with your register number:
   `Figma_UIUX_<RegisterNumber>_03-10-2026`
2. Fill in your name, register number and Figma link in `README.md`.
3. Put your exported PNGs into the matching `screenshots/` sub-folders.
4. Add your `Figma_Screenshots.pdf` (made from the Word template) to the folder root.
5. On github.com click **New repository**, use the same name as the folder, set it to **Public**, and do not tick "Add a README".
6. In a terminal inside the folder:

```bash
git init
git add .
git commit -m "Figma UI/UX class activity"
git branch -M main
git remote add origin https://github.com/<your-username>/Figma_UIUX_<RegisterNumber>_03-10-2026.git
git push -u origin main
```

No terminal? Use **Add file → Upload files** on the repo page and drag the contents in.

## Final checklist
- [ ] Repo name matches `Figma_UIUX_<RegisterNumber>_03-10-2026`
- [ ] Repo is Public
- [ ] Figma file sharing: Share → "Anyone with the link" → Can view
- [ ] Prototype opens in an incognito window
- [ ] README has the working Figma link
- [ ] PDF with all 25 screens (+ mobile layouts for Scenario 5) uploaded
