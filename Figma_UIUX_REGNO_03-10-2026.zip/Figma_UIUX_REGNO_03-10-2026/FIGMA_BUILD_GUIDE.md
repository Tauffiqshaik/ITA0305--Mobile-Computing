# Figma Build Guide – All 5 Scenarios

Use this as your working checklist. Everything is built by you in Figma; this tells you what to put where.

## 0. One-time setup (do this first)
1. New Figma Design file → name it `Figma_UIUX_<RegisterNumber>`.
2. Create 5 **Pages**, one per scenario.
3. **Mobile frame:** press `F` → choose iPhone 14 (390×844). **Desktop frame:** 1440×1024.
4. **Styles** (Local styles → +): create colors, and text styles `H1 28/Bold`, `H2 20/SemiBold`, `Body 16/Regular`, `Caption 12/Regular`. Use font **Inter** throughout.
5. **Icons:** install the plugin *Iconify* or *Lucide Icons* (Resources `Shift+I`).
6. **Images:** use plugin *Unsplash* (food, clothes, doctors) or *Content Reel* for names and avatars.
7. **Shortcuts:** Auto Layout `Shift+A`, Create component `Ctrl/Cmd+Alt+K`, Prototype tab `Shift+E`.

**Auto Layout settings for most things:** vertical, gap 16, padding 16–24. Buttons: horizontal, padding 12/24, radius 12, "Hug" width or "Fill" in forms.

**Prototype connection (same every time):** switch to Prototype tab → drag the blue handle from a button to the next frame → Interaction **On click**, Action **Navigate to**, Animation **Smart animate** (or *Move in – Left*), 300 ms. Set the first screen as the **Flow starting point**. Add a Back arrow on every screen after the first.

## Reusable components (make once, reuse everywhere)
| Component | Variants / notes |
|---|---|
| Primary Button | States: Default, Pressed, Disabled |
| Input Field | States: Default, Focused, Error |
| Bottom Nav Bar | 4 icons; variant for each active tab |
| Card | Image + title + subtitle + price/rating |
| Top App Bar | Back arrow + title |

---

## Scenario 1 – Online Food Delivery App
**Palette:** Primary `#FF5A3C`, Dark `#1F2937`, Light BG `#FFF7F5`, Gray `#6B7280`, Success `#16A34A`

| # | Screen | Contents to place |
|---|--------|-------------------|
| 1 | **Login** | Logo/app name "FoodieGo"; Email input; Password input (eye icon); **Login** button; "Forgot Password?" text link |
| 2 | **Home** | Search bar ("Search for food or restaurants"); horizontal row of category chips (Pizza, Burger, Biryani, Desserts, Drinks) with icons; vertical list of 3–4 **Restaurant cards** (photo, name, rating ★4.5, delivery time 30 min); bottom nav (Home, Search, Cart, Profile) |
| 3 | **Restaurant Menu** | Header image; restaurant name + rating; list of food items – image, name, price (₹199), green **Add** button |
| 4 | **Cart** | Item rows with − 1 + quantity controls; bill summary (Subtotal, Delivery, **Total ₹548**); **Checkout** button |
| 5 | **Order Confirmation** | Green check icon; "Order Placed!"; Order No. `#FD2026105`; Total; status tracker (Confirmed → Preparing → On the way); Estimated delivery **35 mins** |

**Flow:** Login button → Home; restaurant card → Menu; Add / cart icon → Cart; Checkout → Confirmation.

---

## Scenario 2 – College Student Attendance App
**Palette:** Primary `#2563EB`, Present `#16A34A`, Absent `#DC2626`, Leave `#F59E0B`, BG `#F3F6FF`

| # | Screen | Contents to place |
|---|--------|-------------------|
| 1 | **Login** | College logo; Student ID input; Password input; **Login** button |
| 2 | **Dashboard** | Student name, register number; large circular **overall attendance 86%**; list of subject cards (Maths 90%, DBMS 82%, OS 85%, CN 88%) with progress bars; bottom nav |
| 3 | **Subject Details** | Subject name; Classes Conducted `40`; Classes Attended `36`; Percentage `90%`; progress ring; short status text ("Safe – above 75%") |
| 4 | **Attendance Calendar** | Month grid (Oct 2026); dates colored dot/background: green Present, red Absent, amber Leave; legend row below |
| 5 | **Profile** | Round student photo; name; department; year; register number; Logout button |

**Flow:** Login → Dashboard; subject card → Subject Details; nav "Calendar" → Calendar; nav "Profile" → Profile; nav "Home" → Dashboard.
**Required:** buttons + nav bar as components; Auto Layout on cards.

---

## Scenario 3 – E-Commerce Clothing App
**Palette:** Primary `#111827`, Accent `#E11D48`, BG `#FFFFFF`, Surface `#F5F5F4`

| # | Screen | Contents to place |
|---|--------|-------------------|
| 1 | **Home** | Search bar; category chips (Men, Women, Kids, Sale); promotional banner ("Flat 40% OFF"); 2-column grid of featured product cards |
| 2 | **Product Listing** | Top bar with **Filter** icon; 2-column product cards: image, name, price, rating ★ |
| 3 | **Product Details** | Large product image; name; price ₹1,499; description; **size selector S M L XL**; **Add to Cart** button |
| 4 | **Shopping Cart** | Product rows with image, name, size, price, − qty +; Total; **Proceed to Checkout** |
| 5 | **Checkout** | Delivery address card; payment options (UPI / Card / COD radio); Order total; **Place Order** button |

**Variants (required):** create a component `Size Button` with a property *State* = Default / Selected / Disabled (Selected: filled dark with white text; Disabled: gray with strike-through). Place 4 instances on the details screen and show a different state on each (e.g. M selected, XL disabled).
**Flow:** Home card → Listing; product → Details; Add to Cart → Cart; Checkout → Checkout. In Prototype, add an interaction on the size buttons: *On click → Change to → Selected variant*.

---

## Scenario 4 – Hospital Appointment Booking
**Palette:** Primary `#0EA5A4` (teal), Dark `#0F172A`, BG `#F0FDFA`, Alert `#EF4444`

| # | Screen | Contents to place |
|---|--------|-------------------|
| 1 | **Welcome / Login** | Hospital logo + name ("CarePlus Hospital"); Patient ID/Email; Password; **Login** button |
| 2 | **Doctor Search** | Search bar; specialty chips (Cardiology, Neurology, Pediatrics, Ortho); filters icon; doctor cards (photo, name, specialty, ★ rating) |
| 3 | **Doctor Profile** | Large doctor photo; name; specialization; experience (12 years); fee ₹600; time-slot chips (10:00, 11:30, 2:00 PM); **Book Appointment** |
| 4 | **Appointment Booking** | Selected doctor mini-card; date picker (row of next 7 dates); slot chips; **Confirm Booking** |
| 5 | **Confirmation** | Check icon; Patient name; Doctor name; Date; Time; Appointment ID `APT-20261005-01` |

**Flow (required):** Doctor card → Profile → Book Appointment → Booking → Confirm → Confirmation. Use consistent typography (only Inter, text styles from setup).

---

## Scenario 5 – College Event Registration Website (Responsive)
**Palette:** Primary `#7C3AED`, Dark `#111827`, Accent `#06B6D4`, BG `#FAF5FF`

Build every page **twice**: Desktop 1440 wide and Mobile 390 wide (10 frames total).

| # | Page | Contents to place |
|---|------|-------------------|
| 1 | **Home** | Navbar (logo, Home, Events, Register); hero with event title "TechNova 2026", date, venue, **Register Now** button |
| 2 | **Events** | Grid of event cards (Paper Presentation, Hackathon, Web Design, Quiz): name, description, date, **Register** button |
| 3 | **Event Details** | Description; Rules (bulleted); Eligibility; Schedule table; **Register for this event** |
| 4 | **Registration** | Form: Name, Email, Department (dropdown), Year (dropdown), Selected Event; **Submit** |
| 5 | **Confirmation** | Check icon; "Registration Successful"; Registration ID `TN26-0142`; event name; date |

**Responsive tips:** Use Auto Layout *wrap* for card grids (3 columns on desktop → 1 on mobile). Add a 12-column layout grid on desktop (margin 80, gutter 24) and 4-column grid on mobile (margin 20). On mobile replace the navbar with a hamburger icon.
**Flow:** Home → Events → Event Details → Registration → Confirmation (create the flow separately for desktop and mobile).

---

## Export & submit
1. Select all frames of a scenario → right panel **Export** → PNG, 2x → Export. Save into the matching `screenshots/` sub-folder.
2. Paste each screen into `Figma_Screenshots_Template.docx`, add your name/register number, then **File → Save as PDF** and name it `Figma_Screenshots.pdf`.
3. Prototype link: top right **Share** → "Anyone with the link" → **Can view**. Then press ▶ (Present) and copy that URL for the prototype link.
4. Paste the link in `README.md` and follow `setup_github.md`.
